#include<stdio.h>
#include"expre.h"


int main(){

	char* e;
	ex_tree t;
	
	printf("\nEnter the infix expression\n");
	scanf("%ms",&e);
	initTree(&t,e);
	return 0;
}
