#include<stdlib.h>
#include"expre.h"
#include"stack.h"
#include"stack2.h"


node* createNode(char c){
	node* temp = (node*) malloc (sizeof(node));
	if(!temp)
		return NULL;
	temp -> c = c;
	temp -> left = NULL;
	temp -> right = NULL;
	return temp;
}

void initTree(ex_tree* t,char* e){

	stackN s1;
	init1(&s1);
	stackO s2;
	init2(&s2);
	
	for(int i = 0;e[i] != '\0';i++){



	return;
}
	
	 

