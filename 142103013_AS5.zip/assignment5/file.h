
FILE* randomIntegers();
